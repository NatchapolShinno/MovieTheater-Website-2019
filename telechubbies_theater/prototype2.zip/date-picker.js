$(function () {
                $('#datetimepicker1').datetimepicker();
            });
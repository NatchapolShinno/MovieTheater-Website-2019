(()=>{
    function setup() {
        const canvas = document.getElementById('fixImage');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    function run(){
        setup();
    }
    run();
})();
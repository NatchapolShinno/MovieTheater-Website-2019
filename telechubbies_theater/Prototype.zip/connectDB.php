<?php 
$host = "34.87.179.193";
$dbUsername = "root";
$dbPassword = "telechubbies";
$dbName = "telechubbies_theater";

$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
$db = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);

?>